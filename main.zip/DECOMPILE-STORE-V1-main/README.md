## more scripts coming 🤣😹



🥀😻WELCOME TO MY PROFILE🥰


🔥 FLAME NAIM 🔥
 ! 


![Alt text](https://camo.githubusercontent.com/ebf84be3c9b929b89ce2dbe8489c6df660a086d4785f432186b654cab36616c3/68747470733a2f2f6a2e746f7034746f702e696f2f705f31393636736b677738302e6a7067)

![Alt text](https://github.com/MRVIVEK-CODER/MRVIVEK-CODER/raw/main/md7Oqrf.gif)

- ![Alt text](https://github.com/MRVIVEK-CODER/MRVIVEK-CODER/raw/main/Developer.gif)

<!--
**Naim75o/Naim75o** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.





Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->

> MY PROFILE VISITORS :

![Visitor Count](https://profile-counter.glitch.me/Naim75o/count.svg)

- ![Profile views](https://gpvc.arturio.dev/Naim75o)
- [![GitHub followers](https://img.shields.io/github/followers/Naim75o.svg?style=social&label=Follow&maxAge=0090900)](https://github.com/Naim75o?tab=followers)

![Alt text](https://camo.githubusercontent.com/bdc2bf0e7c954ae3cecff56b9712a4411a87c014780b8de8ee050f4f6a3c7b55/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f57686174736170702d626c61636b3f7374796c653d666f722d7468652d6261646765266c6f676f3d7768617473617070)

> GITHUB STATES :

<a href="https://github.com/naiyan-official"><img width=550 src="https://github-profile-trophy.vercel.app/?username=niloy0&theme=dracula&no-frame=true&title=Followers,Stars,Commit,Repository,Issues"/></a>

![Anurag's github stats](https://github-readme-stats.vercel.app/api?username=Naim75o&theme=merko)

[![GitHub Streak](http://github-readme-streak-stats.herokuapp.com?user=niloy0&theme=merko&date_format=M%20j%5B%2C%20Y%5D)](https://git.io/streak-stats)

<img align="center" src="https://github-readme-stats.anuraghazra1.vercel.app/api/top-langs/?username=MohsinTheLegend&layout=compact&theme=chartreuse-dark" />

> CONTACT WITH ME :

<p align="left">


<a href="https://fb.com/Naim.Vau80" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/facebook.svg" alt="NILOY.VAU.6" height="30" width="40" /></a>
<a href="https://instagram.com/FLAME NAIM" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="https://www.instagram.com/md_niloy_48/" height="30" width="40" /></a>



[<img src='https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/github.svg' alt='github' height='40'>](https://github.com/niloy0) <a href="https://github.com/niloy0"></a>

</p>

![](https://img.shields.io/badge/<N1LOY_V4U>-<niloy0-H4CK3R>-informational?style=flat&logo=data:image/svg%2bxml;base64,<BASE64_DATA>)

<img src="https://github.com/Voyz/voyz_public/blob/master/databay_promo_vidA_gif_A03.gif" alt="Databay showcase gif" title="Databay showcase gif" width="500"/>

![Alt text](https://github.com/MRVIVEK-CODER/Decompiler/raw/main/106824690-8dd73a00-66ad-11eb-89e2-53e13ac6f594.gif)

<p align="center">
<a href="https://github.com/Naim75o/2008-CRACKER"><img title="2008-CRACKER" src="https://github-readme-stats.vercel.app/api/pin/?username=Naim75o&repo=2008-CRACKER&theme=vision-friendly-dark"></a>

<p align="center">
<a href="https://github.com/Naim75o/encrypt_decrypt"><img title="encrypt_decrypt" src="https://github-readme-stats.vercel.app/api/pin/?username=Naim75o&repo=encrypt_decrypt&theme=chartreuse-dark"></a>

<p align="center">
<a href="https://github.com/Naim75o/BD-11-DIGIT"><img title="BD-11-DIGIT" src="https://github-readme-stats.vercel.app/api/pin/?username=Naim75o&repo=BD-11-DIGIT&theme=highcontrast"></a>

<p align="center">
<a href="https://github.com/Naim75o/MULTI-PUBLIC"><img title="MULTI-PUBLIC" src="https://github-readme-stats.vercel.app/api/pin/?username=Naim75o&repo=MULTI-PUBLIC&theme=midnight-purple"></a>

<p align="center">
<a href="https://github.com/Naim75o/decrypt"><img title="decrypt" src="https://github-readme-stats.vercel.app/api/pin/?username=Naim75o&repo=decrypt&theme=vision-friendly-dark"></a>

<p align="center">
<a href="https://github.com/Naim75o/FLAME-2K9"><img title="FLAME-2K9" src="https://github-readme-stats.vercel.app/api/pin/?username=Naim75o&repo=FLAME-2K9&theme=vision-friendly-dark"></a>



> DATABASE:

<p>
  <img src="https://img.shields.io/badge/MySQL-00000F?style=for-the-badge&logo=mysql&logoColor=white" />
  <img src="https://img.shields.io/badge/PostgreSQL-316192?style=for-the-badge&logo=postgresql&logoColor=white" />
  <img src="https://img.shields.io/badge/MongoDB-4EA94B?style=for-the-badge&logo=mongodb&logoColor=white" />
  <img src="https://img.shields.io/badge/SQLite-07405E?style=for-the-badge&logo=sqlite&logoColor=white" />
</p>

> TOOLS :

![AWS](https://img.shields.io/badge/-AWS-000?&logo=Amazon-AWS&logoColor=F90)
![Docker](https://img.shields.io/badge/-Docker-000?&logo=Docker)
![Kubernetes](https://img.shields.io/badge/-Kubernetes-000?&logo=Kubernetes)
![Linux](https://img.shields.io/badge/-Linux-000?&logo=Linux)
![Node.js](https://img.shields.io/badge/-Node.js-000?&logo=node.js)
![PyTorch](https://img.shields.io/badge/-PyTorch-000?&logo=PyTorch)
![React](https://img.shields.io/badge/-React-000?&logo=React)
![Redis](https://img.shields.io/badge/-Redis-000?&logo=Redis)
![Spring](https://img.shields.io/badge/-Spring-000?&logo=Spring)
![TensorFlow](https://img.shields.io/badge/-TensorFlow-000?&logo=TensorFlow)

> PROGRAMMING LANGUAGE :

![Python](https://img.shields.io/badge/-Python-000?&logo=Python)
![JavaScript](https://img.shields.io/badge/-JavaScript-000?&logo=JavaScript)
![C](https://img.shields.io/badge/-C-000?&logo=C)
![Java](https://img.shields.io/badge/-Java-000?&logo=Java&logoColor=007396)
![TypeScript](https://img.shields.io/badge/-TypeScript-000?&logo=TypeScript)
![C++](https://img.shields.io/badge/-C++-000?&logo=c%2b%2b&logoColor=00599C)
![SQL](https://img.shields.io/badge/-SQL-000?&logo=MySQL)
![Swift](https://img.shields.io/badge/-Swift-000?&logo=Swift)







